﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text; 

namespace NHSPatServices
{
    public class Service1 : IService1
    {
        //create object to connect service to database entities
        NHSPatServ.NHSPatientServicesEntities dbContext;
        
        public Service1()
        {
            dbContext = new NHSPatServ.NHSPatientServicesEntities();

        }

        //this method returns a list of objects which can be plotted on a map
        public List<MappableObject> GetMappableObjects(string gp, string question, string diseaseName = "Asthma")
        {
            SearchCriteria searchQuery = new SearchCriteria(gp, question, diseaseName);
            List<MappableObject> myList = new List<MappableObject>();
            MappableObject pobj;
              

            foreach (NHSPatServ.sp_plot_Result r in dbContext.sp_plot())
            {
                pobj = new MappableObject(r.Parent_Name, (double)r.Latitude, (double)r.Longitude, (double)r.Average_Number_of_Staff);
                myList.Add(pobj);

            }
            int i = 0;
            foreach (NHSPatServ.sp_diseasesInNhsTrust_Result v in dbContext.sp_diseasesInNhsTrust(searchQuery.disease.Code))
            {
                myList.ElementAt(i).diseaseTotal = (double)v.Average;
                i++;

            }



            return myList ;
            
        }

     
        //this method returns a list of objects which can be plotted on a graph. the list is determined by the search criteria
        public List<PlottableObject> GetPlottableObjects(string gp, string question, string diseaseName = "Asthma" )
        {
            SearchCriteria searchQuery = new SearchCriteria(gp, question, diseaseName);
            List<PlottableObject> test = new List<PlottableObject>();
            switch (searchQuery.question)
            {
                case "AverageAllDiseaseInEngland":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (NHSPatServ.sp_AverageAllDiseaseInEngland_Result r in dbContext.sp_AverageAllDiseaseInEngland())
                        {
                            obj = new PlottableObject(r.Disease_Name.TrimEnd(), (double)(r.Average_Number_of_Cases));
                            objList.Add(obj);
                        }

                        return objList;


                    }
                    catch { Exception ex; }

                    break;

                case "AverageAllDiseaseInNHSTrust":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        foreach (NHSPatServ.sp_AverageAllDiseaseInNHSTrust_Result r in dbContext.sp_AverageAllDiseaseInNHSTrust(searchQuery.gp))
                        {
                            obj = new PlottableObject(r.disease_name.TrimEnd(), (double)(r.Average));
                            objList.Add(obj);
                        }
                        return objList;
                    }
                    catch { Exception ex; }
                    break;
                case "AveragePatientInEngland":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        var result = (dbContext.sp_AveragePatientInEngland());
                        if (result != null)
                        {
                            obj = new PlottableObject("Average number of patients in England", (double)result.FirstOrDefault());
                            objList.Add(obj);

                        }//end if
                        return objList;
                    }
                    catch { Exception ex; }
                    break;
                case "AveragePatientInNHSTrust":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        var result = dbContext.sp_AveragePatientInNHSTrust(searchQuery.gp);

                        if (result != null)
                        {
                            foreach (var r in dbContext.sp_AveragePatientInNHSTrust(searchQuery.gp))
                            {
                                obj = new PlottableObject("Average number of patients in NHS Trust", (double)r.Value);
                                objList.Add(obj);

                            }
                            return objList;
                        }
                    }
                    catch { Exception ex; }
                    break;
                case "AverageRatingInEngland":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        var result = dbContext.sp_AverageRatingInEngland();

                        if (result != null)
                        {
                            foreach (NHSPatServ.sp_AverageRatingInEngland_Result r in dbContext.sp_AverageRatingInEngland())
                            {
                                obj = new PlottableObject("Very Poor", (double)r.Q14_Cant_Remember);
                                objList.Add(obj);
                                obj = new PlottableObject("Poor", (double)r.Q14_Few_Days_Later);
                                objList.Add(obj);
                                obj = new PlottableObject("Ok", (double)r.Q14_Week_Or_More);
                                objList.Add(obj);
                                obj = new PlottableObject("Good", (double)r.Q14_Next_Working_Day);
                                objList.Add(obj);
                                obj = new PlottableObject("Excellent", (double)r.Q14_On_Same_day);
                                objList.Add(obj);

                            }
                            return objList;
                        }
                    }
                    catch { Exception ex; }
                    break;
                case "AverageRatingInTrust":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        foreach (NHSPatServ.sp_AverageRatingInTrust_Result r in dbContext.sp_AverageRatingInTrust(searchQuery.gp))
                        {
                            obj = new PlottableObject("Can't remember", (double)r.Q14_Cant_Remember);
                            objList.Add(obj);
                            obj = new PlottableObject("Few days later", (double)r.Q14_Few_Days_Later);
                            objList.Add(obj);
                            obj = new PlottableObject("A week or more", (double)r.Q14_Week_Or_More);
                            objList.Add(obj);
                            obj = new PlottableObject("Next working day", (double)r.Q14_Next_Working_Day);
                            objList.Add(obj);
                            obj = new PlottableObject("On same day", (double)r.Q14_On_Same_day);
                            objList.Add(obj);

                        }
                    }
                    catch { Exception ex; }
                    break;
                case "AverageSpecificDiseaseInEngland":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (NHSPatServ.sp_AverageSpecificDiseaseInEngland_Result r in dbContext.sp_AverageSpecificDiseaseInEngland(searchQuery.disease.Code))
                        {
                            obj = new PlottableObject(r.Indicator_Group.TrimEnd(), (int)r.average);
                            objList.Add(obj);

                        }
                        return objList;
                    }
                    catch { Exception ex; }
                    break;
                case "AverageSpecificDiseaseInNHSTrust":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        string name = "didnt work";

                        foreach (string s in dbContext.sp_NameOfTrust(searchQuery.gp))
                        {
                            name = s;
                        }

                        foreach (int r in dbContext.sp_AverageSpecificDiseaseInNHSTrust(searchQuery.disease.Code, searchQuery.gp))
                        {
                            obj = new PlottableObject(name, (int)r);
                            objList.Add(obj);

                        }
                        return objList;
                    }

                    catch { Exception ex; }
                    break;
                case "AverageStaffInEngland":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        var result = dbContext.sp_AverageStaffInEngland();

                        if (result != null)
                        {
                            foreach (var r in result)
                            {
                                obj = new PlottableObject("Average number of staff in England", (double)r.Value);
                                objList.Add(obj);

                            }
                            return objList;
                        }
                    }
                    catch { Exception ex; }
                    break;
                case "AverageStaffInNHSTrust":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        var result = dbContext.sp_AverageStaffInNHSTrust(searchQuery.gp);

                        if (result != null)
                        {
                            foreach (var r in result)
                            {
                                obj = new PlottableObject("Average number of Staff in Trust", (double)r.Value);
                                objList.Add(obj);

                            }
                            return objList;
                        }
                    }
                    catch { Exception ex; }
                    break;

                case "MaxAllDiseaseInEngland":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        foreach (NHSPatServ.sp_MaxAllDiseaseInEngland_Result r in dbContext.sp_MaxAllDiseaseInEngland())
                        {
                            obj = new PlottableObject(r.Disease_Name.TrimEnd(), (int)(r.Max_Number_of_cases));
                            objList.Add(obj);

                        }
                        return objList;
                    }
                    catch { Exception ex; }
                    break;
                case "MaxAllDiseaseInNHSTrust":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (NHSPatServ.sp_MaxAllDiseaseInNHSTrust_Result r in dbContext.sp_MaxAllDiseaseInNHSTrust(searchQuery.gp))
                        {
                            obj = new PlottableObject(r.Disease_Name, (int)(r.Max_Number_of_Cases));
                            objList.Add(obj);

                        }
                        return objList;
                    }
                    catch { Exception ex; }
                    break;
                case "MaxSpecificDiseaseInEngland":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        var result = dbContext.sp_MaxSpecificDiseaseInEngland(searchQuery.disease.Code);

                        if (result != null)
                        {
                            foreach (var r in result)
                            {
                                obj = new PlottableObject("Max number of disease", (int)r.Value);
                                objList.Add(obj);

                            }
                            return objList;
                        }
                    }
                    catch { Exception ex; }
                    break;
                case "MaxSpecificDiseaseInNHSTrust":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        foreach (NHSPatServ.sp_MaxSpecificDiseaseInNHSTrust_Result r in dbContext.sp_MaxSpecificDiseaseInNHSTrust(searchQuery.disease.Code, searchQuery.gp))
                        {
                            obj = new PlottableObject(r.Disease_Name.TrimEnd(), (int)(r.Max_Number_of_Cases));
                            objList.Add(obj);

                        }
                        return objList;
                    }
                    catch { Exception ex; }
                    break;
                case "MinAllDiseaseInEngland":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        foreach (NHSPatServ.sp_MinAllDiseaseInEngland_Result r in dbContext.sp_MinAllDiseaseInEngland())
                        {
                            obj = new PlottableObject(r.Disease_Name.TrimEnd(), (int)r.Min_Number_of_Cases);
                            objList.Add(obj);

                        }
                        return objList;

                    }
                    catch { Exception ex; }
                    break;
                case "MinAllDiseaseInNHSTrust":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();

                        foreach (NHSPatServ.sp_MinAllDiseaseInNHSTrust_Result r in dbContext.sp_MinAllDiseaseInNHSTrust(searchQuery.gp))
                        {
                            obj = new PlottableObject(r.disease_name.TrimEnd(), (int)r.Min_Number_of_Cases);
                            objList.Add(obj);
                        }

                        return objList;


                    }
                    catch { Exception ex; }
                    break;

                case "MinSpecificDiseaseInEngland":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (int? r in dbContext.sp_MinSpecificDiseaseInEngland(searchQuery.disease.Code.ToString()))
                        {
                            obj = new PlottableObject("Min Disease Occurance in England", (int)r.Value);
                            objList.Add(obj);
                        }

                        return objList;


                    }
                    catch { Exception ex; }
                    break;
                case "MinSpecificDiseaseInNHSTrust":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (int? r in dbContext.sp_MinSpecificDiseaseInNHSTrust(searchQuery.disease.Code.ToString(), searchQuery.gp))
                        {
                            obj = new PlottableObject("Min Desease occurance in NHS Trust", (int)r.Value);
                            objList.Add(obj);
                        }

                        return objList;


                    }
                    catch { Exception ex; }
                    break;
                // returns the total number of a specific disease from a specific gp
                case "TotalAllDiseaseInSpecificGP":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (NHSPatServ.sp_TotalAllDiseaseInSpecificGP_Result r in dbContext.sp_TotalAllDiseaseInSpecificGP(searchQuery.gp))
                        {
                            obj = new PlottableObject(r.Disease_Name.TrimEnd(), (int)r.Number_of_cases);
                            objList.Add(obj);
                        }

                        return objList;


                    }
                    catch { Exception ex; }
                    break;

                case "TotalPatientInSpecificGP":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (int? r in dbContext.sp_TotalPatientInSpecificGP(searchQuery.gp))
                        {
                            obj = new PlottableObject("Total number of patients", (int)r.Value);
                            objList.Add(obj);
                        }

                        return objList;


                    }
                    catch { Exception ex; }
                    break;
                //returns the total rating for a particular gp with regards waiting times
                case "TotalRatingInGP":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (NHSPatServ.sp_TotalRatingInGP_Result r in dbContext.sp_TotalRatingInGP(searchQuery.gp))
                        {
                            obj = new PlottableObject("Very Poor", (double)r.Q14_Cant_Remember);
                            objList.Add(obj);
                            obj = new PlottableObject("Poor", (double)r.Q14_Few_Days_Later);
                            objList.Add(obj);
                            obj = new PlottableObject("OK", (double)r.Q14_Week_Or_More);
                            objList.Add(obj);
                            obj = new PlottableObject("Good", (double)r.Q14_Next_Working_Day);
                            objList.Add(obj);
                            obj = new PlottableObject("Excellent", (double)r.Q14_On_Same_day);
                            objList.Add(obj);
                        }

                        return objList;


                    }
                    catch { Exception ex; }
                    break;
                //this element returns the title and count of a particular illness
                case "TotalSpecificDiseaseInGP":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (NHSPatServ.sp_TotalSpecificDiseaseInGP_Result r in dbContext.sp_TotalSpecificDiseaseInGP(searchQuery.disease.Code.ToString(), searchQuery.gp))
                        {
                            obj = new PlottableObject(r.Disease_Name.TrimEnd(), (int)r.Number_of_cases);
                            objList.Add(obj);
                        }

                        return objList;
                    }
                    catch { Exception ex; }
                    break;

                //this element of the switch returns the title and quantity of each type 
                //of staff employed at a single gp practice
                case "TotalStaffInSpecificGP":
                    try
                    {
                        PlottableObject obj;
                        List<PlottableObject> objList = new List<PlottableObject>();
                        foreach (NHSPatServ.sp_TotalStaffInSpecificGP_Result r in dbContext.sp_TotalStaffInSpecificGP(searchQuery.gp))
                        {
                            obj = new PlottableObject(r.Job_Title.TrimEnd(), (int)r.Total);
                            objList.Add(obj);
                        }

                        return objList;


                    }
                    catch { Exception ex; }
                    break;
            }
            return test;
        }
    }

   
}
