﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using dotNetHighcharts.DAL;
using DotNet.Highcharts.Options;
using DotNet.Highcharts.Helpers;
using System.Drawing;
using DotNet.Highcharts.Enums;
using DotNet.Highcharts;
using dotNetHighcharts.Models;
using dotNetHighcharts.ServiceReference1;


namespace dotNetHighcharts.Controllers
{
    public class ServicesOrganisationsController : Controller
    {
        

        Service1Client proxy = new Service1Client();

        public ActionResult GraphDisplayingDiseasePrevalance()
        {
            //these details would be elicited through the parameters of this method given further development time
            string gp = "A81001";
            string AverageAllDiseaseInEngland = "AverageAllDiseaseInEngland";
            string AverageAllDiseaseInNHSTrust = "AverageAllDiseaseInNHSTrust";
            string TotalAllDiseaseInSpecificGP = "TotalAllDiseaseInSpecificGP";
            string disease = "Asthma";
            List<PlottableObject> AverageAllDiseaseInEnglandData = proxy.GetPlottableObjects(gp, AverageAllDiseaseInEngland, disease);
            List<PlottableObject> AverageAllDiseaseInNHSTrustData = proxy.GetPlottableObjects(gp, AverageAllDiseaseInNHSTrust, disease);
            List<PlottableObject> TotalAllDiseaseInSpecificGPData = proxy.GetPlottableObjects(gp, TotalAllDiseaseInSpecificGP, disease);
            


            //this will object will hold data for AverageAllDiseaseInEngland
            object[] chartData = new object[AverageAllDiseaseInEnglandData.Count()];
            int i = 0;
            foreach (PlottableObject item in AverageAllDiseaseInEnglandData)
            {
                chartData.SetValue(item.Value, i);
                i++;
            }
           
            //this will object will hold data for MaxAllDiseaseInNHSTrust
            object[,] newChartData = new object[AverageAllDiseaseInNHSTrustData.Count(), 2];
            int j = 0;
            foreach (PlottableObject nItem in AverageAllDiseaseInNHSTrustData)
            {
                newChartData.SetValue(nItem.Ref_ID, j, 0);
                newChartData.SetValue(nItem.Value, j, 1);
                j++;
            }
            //this will object will hold data TotalAllDiseaseInSpecificGP
            object[] newLineChartData = new object[TotalAllDiseaseInSpecificGPData.Count()];
            int k = 0;
            foreach (PlottableObject nItem in TotalAllDiseaseInSpecificGPData)
            {
                newLineChartData.SetValue(nItem.Value, k);
                k++;
            }
            YAxis yaxis = new YAxis
            {
                
                Max = 2000,             
            };

            XAxis xaxis = new XAxis {
                

                Type = AxisTypes.Category, Labels = new XAxisLabels() };

            xaxis.Labels.Rotation = -45;
            Highcharts chart1 = new Highcharts("chart1")
                .InitChart(new Chart { Type = ChartTypes.Column })
                .SetTitle(new Title { Text = "NHS Patient Services" })
                 .SetYAxis(yaxis) 
                .SetXAxis(xaxis)
                .SetSeries(new[]
                {
                    new Series {Name = "Average All Diseases England",
                                Color = Color.IndianRed,
                                Data = new Data(chartData) },
                    new Series {Name = "Average All Diseases In NHS Trust",
                                Color = Color.Silver,
                                Data = new Data(newChartData) },
                    new Series
                            {
                                Type = ChartTypes.Line,
                                Name = "A81001 Actual Prevalance",
                                Color = Color.Purple,
                                Data = new Data(newLineChartData)
                            } 
                   
                });
            return View(chart1);
        }

        public ActionResult GraphDisplayingCombinationTrustData()
        {
            //these details would be elicited through the parameters of this method given further development time
            string gp = "A81001";
            string AverageRatingInEngland = "AverageRatingInEngland";
            string AverageStaffInNHSTrust = "AverageStaffInNHSTrust";
            string TotalStaffInSpecificGP = "TotalStaffInSpecificGP";
            string TotalRatingInGP = "TotalRatingInGP";
            string disease = "Asthma";
            List<PlottableObject> AverageRatingInEnglandData = proxy.GetPlottableObjects(gp, AverageRatingInEngland, disease);
            List<PlottableObject> AverageStaffInNHSTrustData = proxy.GetPlottableObjects(gp, AverageStaffInNHSTrust, disease);
            List<PlottableObject> TotalRatingInGPData = proxy.GetPlottableObjects(gp, TotalRatingInGP, disease);
            List<PlottableObject> TotalStaffInSpecificGPData = proxy.GetPlottableObjects(gp, TotalStaffInSpecificGP, disease);
            double totalStaffInParticularGP = 0;
            foreach (PlottableObject p in TotalStaffInSpecificGPData)
            {
                totalStaffInParticularGP += p.Value;
            }

            //this will object will hold data for AverageRatingInTrustData
            object[,] chartData = new object[AverageRatingInEnglandData.Count(),2];
            int i = 0;
            foreach (PlottableObject item in AverageRatingInEnglandData)
            {
                chartData.SetValue(item.Ref_ID, i, 0);
                chartData.SetValue((item.Value/10), i,1);
                i++;
            }
            //this will object will hold data for AverageRatingInTrustData
            object[,] chartData2 = new object[TotalRatingInGPData.Count(), 2];
            int j = 0;
            foreach (PlottableObject item1 in TotalRatingInGPData)
            {
                chartData2.SetValue(item1.Ref_ID, j, 0);
                chartData2.SetValue((item1.Value / 10), j, 1);
                j++;
            }

            YAxis yaxis = new YAxis
            {
                PlotLines = new[]
                {
                    new YAxisPlotLines
                    {
                        Label = new YAxisPlotLinesLabel
                        {
                            Text = "Average Staff Level"
                        },
                        Value = AverageStaffInNHSTrustData.ElementAt(0).Value,
                        Width = 5,
                        Color = Color.Green
                    },
                    new YAxisPlotLines
                    {
                        Label = new YAxisPlotLinesLabel
                        {
                            Text = "Staff Level In " + gp
                        },
                        Value = (totalStaffInParticularGP),
                        Width = 5,
                        Color = Color.Purple
                    }
                },
                Max = 10,
            };

            XAxis xaxis = new XAxis
            {


                Type = AxisTypes.Category,
                Labels = new XAxisLabels()
            };

            xaxis.Labels.Rotation = -45;
            Highcharts chart1 = new Highcharts("chart1")
                .InitChart(new Chart { Type = ChartTypes.Column })
                .SetTitle(new Title { Text = "NHS Patient Services" })
                 .SetYAxis(yaxis)
                .SetXAxis(xaxis)
                .SetSeries(new[]
                {
                    new Series {Name = "Patient Satisfaction in England",
                                Color = Color.Green,
                                Data = new Data(chartData) },
                    new Series {Name = "Patient Satisfaction in " + gp,
                                Color = Color.Purple,
                                Data = new Data(chartData2)}
                });
            return View(chart1);
        }

        //This method returns a map to the view
        public ActionResult HighMap()
        {
            string gp = "A81001";
            string question = "This would have been used in future for ajax calls!";
            string Cancer = "Cancer";
            string Thyroid = "Thyroid";
            string Asthma = "Asthma";
            //bring the mappable objects back from the server 
            List<MappableObject> MapCancer = proxy.GetMappableObjects(gp, question, Cancer);
            List<PlottableObject> cancerAverage = proxy.GetPlottableObjects(gp, "AverageSpecificDiseaseInEngland", "Cancer");
            double averageCancer = cancerAverage.ElementAt(0).Value;
            List<MappableObject> MapThyroid = proxy.GetMappableObjects(gp, question, Thyroid);
            List<PlottableObject> ThyroidAverage = proxy.GetPlottableObjects(gp, "AverageSpecificDiseaseInEngland", "Thyroid");
            double averageThyroid = ThyroidAverage.ElementAt(0).Value;
            List<MappableObject> MapAsthma = proxy.GetMappableObjects(gp, question, Asthma);
            List<PlottableObject> AsthmaAverage = proxy.GetPlottableObjects(gp, "AverageSpecificDiseaseInEngland", "Asthma");
            double averageAsthma = AsthmaAverage.ElementAt(0).Value;
            //create a list of map details
            List<MapDetails> MapCancerList = new List<MapDetails>();
            List<MapDetails> MapThyroidList = new List<MapDetails>();
            List<MapDetails> MapAsthmaList = new List<MapDetails>();
            MapDetails obj;
            //populate the map details list with our mappable objects 
            foreach (MappableObject m in MapCancer)
            {
                if (m.diseaseTotal >= averageCancer) { 
                obj = new MapDetails();
                obj.name = m.Parent_Name;
                obj.avgStaff = m.staffNumbers;
                obj.lat = m.Latitude;
                obj.lon = m.Longitude;
                obj.z = m.diseaseTotal;
                MapCancerList.Add(obj);
            }
            }//end foreach

            //populate the map details list with our mappable objects 
            foreach (MappableObject m in MapThyroid)
            {
                if (m.diseaseTotal >= averageThyroid)
                {
                    obj = new MapDetails();
                    obj.name = m.Parent_Name;
                    obj.avgStaff = m.staffNumbers;
                    obj.lat = m.Latitude;
                    obj.lon = m.Longitude;
                    obj.z = m.diseaseTotal;
                    MapThyroidList.Add(obj);
                }
            }//end foreach

            //populate the map details list with our mappable objects 
            foreach (MappableObject m in MapAsthma)
            {
                if (m.diseaseTotal >= averageAsthma)
                {
                    obj = new MapDetails();
                    obj.name = m.Parent_Name;
                    obj.avgStaff = m.staffNumbers;
                    obj.lat = m.Latitude;
                    obj.lon = m.Longitude;
                    obj.z = m.diseaseTotal;
                    MapAsthmaList.Add(obj);
                }
            }//end foreach

            //set the view bag and send the map to the view
            ViewBag.LocationsCancer = MapCancerList.ToList();
            ViewBag.LocationsThyroid = MapThyroidList.ToList();
            ViewBag.LocationsAsthma = MapAsthmaList.ToList();
            return View();
        }//end HighMap

      
        //CLOSE PROXY UPON DISPOSE
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                proxy.Close();
            }
            base.Dispose(disposing);
        }//end dispose
    }
}

       