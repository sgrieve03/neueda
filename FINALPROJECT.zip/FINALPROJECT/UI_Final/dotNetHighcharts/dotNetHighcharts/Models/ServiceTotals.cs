﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace dotNetHighcharts.Models
{
    public class ServiceTotals
    {
        public string name { get; set; }
        public int TotalServiceType2 { get; set; }
        public int TotalServiceType3 { get; set; }



    }
}